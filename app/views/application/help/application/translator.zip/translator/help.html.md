#Translator Role Help
##Introduction
A single translation consists of the following information
- An application version language
  - For example _Calm version 4 German_
- A code (called Dot Key Code in Translator because the code is a key to the translation). 
  - It is in a form separarated by dots e.g. _activerecord.models.course.location_
- A translation 

##Just want to get started now?
Click [Translations](../translations)

##More Information about Translations
Click [Translation Types](translator_objects)

##To Understand How the Translation Process Works
Click [Translation Process](translation_process)
